import math
def find_min(arr, start, stop):
    """Searches arr[start:stop] for the samllest element.
    
    Assumes arr is a rotated sorted array.
    """
    if ------: # write down appropriate base case; 
        return ----- 

    # you may include more than one base case if needed
    
    mid = math.floor((stop + start) / 2)

    if ----------------:
    
        return arr[---------]
        
    elif ------------------ :
        
        return find_min(----------------)
    
    else:
        
        return find_min(----------------)
